<button type="button" class="btn btn-default">
<span class="glyphicon glyphicon-{{$class}}" aria-hidden="true"></span> {{$class}}
</button>