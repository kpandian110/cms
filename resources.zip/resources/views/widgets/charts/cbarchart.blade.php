
<canvas id="cbar" width="350" height="220"></canvas>